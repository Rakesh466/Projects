package com.parkinglot.Model;

public interface Vehicle {
	public String getColor();

    public String getRegistrationNumber();
}
