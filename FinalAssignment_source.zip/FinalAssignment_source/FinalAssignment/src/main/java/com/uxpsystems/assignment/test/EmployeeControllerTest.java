package com.uxpsystems.assignment.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.uxpsystems.assignment.model.Employee;
import com.uxpsystems.assignment.service.EmployeeService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {TestBeanConfig.class})
public class EmployeeControllerTest {
	@Autowired
	private EmployeeService emplyeecontroller;
	
	@Test 
	public void testEmpList() { 
		   List<Employee> emp = emplyeecontroller.getAllEmployees(); 
		   assertEquals("Employee list can not be empty", emp.size() > 0, emp.size());
		   
		   }
}
