
public class Threads extends Thread{
int total=0;
public void run()
{
	System.out.println("=======");
	synchronized (this) {
		
	
	for (int i=0;i<=100;i++)
	{
		total=total+i;
		System.out.println("===="+total);
	}
	this.notify();
	}
	System.out.println("------");
}
}
