import java.time.LocalDateTime;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class ExecutorServiceExp {
public static void main(String a[])
{
	System.out.println("inside main");
	/*Runnable runnable = () -> {
		try {
            TimeUnit.MILLISECONDS.sleep(1000);
            System.out.println("Current time :: " + LocalDateTime.now());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
	};*/
	ExecutorService execute=Executors.newFixedThreadPool(10);
//execute.execute(runnable);
}
}
