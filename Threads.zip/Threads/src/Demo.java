
public class Demo implements Runnable {
private static final ThreadLocal<Integer> threadlocal=new ThreadLocal<Integer>()
{
        protected Integer initialValue()
        {
           return 1;
}};

public int getThreadId()
{
	System.out.println("Thread Name: "+Thread.currentThread().getName());
	try {
		Thread.sleep(1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return threadlocal.get();
	
}

public void run() 
{
		
		System.out.println(getThreadId());
}

public static void main(String a[])
{
	Thread t=new Thread(new Demo());
	t.start();
	Thread t2=new Thread(new Demo());
	t2.start();
}
}
