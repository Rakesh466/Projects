import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;


public class ProducerConsumerPattern {

	public static void main(String[] args) {

		BlockingQueue sharedBlocking = new LinkedBlockingQueue();
		Thread produTh=new Thread(new Producer(sharedBlocking));
		produTh.start();
		Thread produTh1=new Thread(new Consumer(sharedBlocking));
		produTh1.start();
	}

}
