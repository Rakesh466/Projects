import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;


public class MainS {

	public static void main(String[] args) {
	
		

        StringBuilder sb = new StringBuilder();
String apiName="";
HashMap map=new HashMap();
        try (BufferedReader br = Files.newBufferedReader(Paths.get("D:\\configuration\\file.txt"))) {

           
            String line;
            while ((line = br.readLine()) != null) {
              
                if(map.containsKey(line.toString().split(",")[1]))
                {
                	
                	
                	if((line.split(",")[2].compareTo((String) map.get(line.split(",")[1])))>0)
                	{
                		
                		map.put(line.split(",")[1], line.split(",")[2]);
                		
                	}else
                	{
                		apiName=line.split(",")[0];
                	}
                }else{
                	//System.out.println("mooooo");
                	map.put(line.split(",")[1], line.split(",")[2]);
                }
            }
//System.out.println(sb.toString());
        } catch (Exception e) {
            System.err.format("IOException: %s%n", e);
        }
System.out.println(apiName);
       // System.out.println(sb);
		/*ArrayList<ArrayList<Integer>> li=new ArrayList<ArrayList<Integer>>();

	for(int i=0;i<10000;i++){
		try{
			li.add(new ArrayList<Integer>(1000000));
		}catch(OutOfMemoryError e)
		{
			System.out.println(e);
		}
	}*/
	}

}
