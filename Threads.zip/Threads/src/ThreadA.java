
public class ThreadA {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
Threads b=new Threads();
b.start();
//Thread.sleep(10);
//b.join();
synchronized (b) {
	b.wait();	
}	

System.out.println("::"+b.total);
	}

}
