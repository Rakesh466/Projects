import java.util.concurrent.BlockingQueue;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Consumer implements Runnable{
private final BlockingQueue sharedQuequ;
public Consumer(BlockingQueue shBlockingQueue)
{
	this.sharedQuequ=shBlockingQueue;
}
	public void run() {
		
		while(true){
            try {
                System.out.println("Consumed: "+ sharedQuequ.take());
            } catch (InterruptedException ex) {
                Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
            }
		}

	}

}
