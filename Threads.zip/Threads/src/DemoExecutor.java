import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;


public class DemoExecutor {

	public static void main(String[] args) {

		Integer threadCount=0;
		BlockingQueue<Runnable> blockingQueue=new ArrayBlockingQueue<Runnable>(10);
		CustomThreadPoolExecutor executor = new CustomThreadPoolExecutor(10,
                20, 5000, TimeUnit.MILLISECONDS, blockingQueue);
		
		executor.setRejectedExecutionHandler(new RejectedExecutionHandler() {
			public void rejectedExecution(Runnable r,ThreadPoolExecutor executor) 
			{
               
                System.out.println("Waiting for a second !!");
                try{ 
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                
                executor.execute(r);
            }
		});
		
		executor.prestartAllCoreThreads();
        while (true) {
            threadCount++;
            // Adding threads one by one
            System.out.println("Adding DemoTask : " + threadCount);
           // executor.execute(new DemoTask(threadCounter.toString()));
 
            if (threadCount == 100)
                break;	
        }
	}

}
