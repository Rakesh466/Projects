import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class MainPost {

	public static void main(String[] args) {
		HttpURLConnection urlConn=null;
		BufferedReader rader=null;
		String strUrl="http://localhost:8080/employees/1";
		try{
			URL url=new URL(strUrl);
			urlConn=(HttpURLConnection)url.openConnection();
			urlConn.setConnectTimeout(5000);
			urlConn.setReadTimeout(5000);
			urlConn.setRequestMethod("GET");
			urlConn.setRequestProperty("Accept","application/json");
			if(urlConn.getResponseCode() !=HttpURLConnection.HTTP_OK)
			{
				System.out.println("unable to connect");
				return;
			}
			InputStream inputStream=urlConn.getInputStream();
			rader=new BufferedReader(new InputStreamReader(inputStream));
			String tmpStr=null;
			
			while((tmpStr =rader.readLine())!=null)
			{
				System.out.println(tmpStr);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}

	}

}
