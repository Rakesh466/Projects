import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


public class JersyGetClient {

	public static void main(String[] args) {
		String strUrl="http://localhost:8080/employees/1";
		Client client=Client.create();
		WebResource webResource=client.resource(strUrl);
		ClientResponse clientResponse=webResource.accept("application/json").get(ClientResponse.class);
		if(clientResponse.getStatus()!=200)
		{
			System.out.println("unable to connect...");
			return;
		}
		String response=clientResponse.getEntity(String.class);
		System.out.println(response);
	}

}
