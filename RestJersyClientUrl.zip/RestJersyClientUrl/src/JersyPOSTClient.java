import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;


public class JersyPOSTClient {
public static void main(String a[])
{
	String strUrl="http://localhost:8080/employees/";
	Client client=Client.create();
	String input="1";
	WebResource webResource= client.resource(strUrl);
	ClientResponse clientResponse=webResource.accept("application/json").post(ClientResponse.class,input);
	if(clientResponse.getStatus()!=200)
	{
		System.out.println("unable to connect.....");
		return;
	}
	String response=clientResponse.getEntity(String.class);
	System.out.println(response);
}
}
