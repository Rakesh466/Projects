import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Mainclass {

	public static void main(String[] args) {

		String urlstr="http://localhost:8080/Welcome";
		HttpURLConnection  conn=null;
		BufferedReader reader=null;
		try{
		URL url=new URL(urlstr);
		conn=(HttpURLConnection)url.openConnection();
		conn.setRequestMethod("GET");
		conn.setConnectTimeout(5000);
		conn.setReadTimeout(5000);
		conn.setRequestProperty("Accept","application/json");
		
		if(conn.getResponseCode()!=HttpURLConnection.HTTP_OK)
		{
			 System.err.println("Unable to connect to the URL...");
             return;
		}
		
	   System.out.println("Connected to the server...");
			  InputStream is= conn.getInputStream();
			reader= new BufferedReader( new InputStreamReader(is));
			String tmpStr=null;
			while((tmpStr =reader.readLine())!=null)
			{
				System.out.println(tmpStr);
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}

