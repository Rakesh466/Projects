package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeServiceController {
	private static final Map<Integer, Employee> employeeData = 
		new HashMap<Integer,Employee>(); 

	/*
	 * static { employeeData.put(111,new Employee(111,"Employee1"));
	 * employeeData.put(222,new Employee(222,"Employee2")); }
	 */
@RequestMapping(value="/findEmployeeDetails/{employeeId}",method=RequestMethod.GET)
public Employee getEmployeeList(@PathVariable int employeeId)
{
	System.out.println("employeeId:"+employeeId);
	Employee employee=new Employee(111,"Employee1");
	employee.setId(111);
	employee.setName("EmployeeS");
	return employee;
}
}
