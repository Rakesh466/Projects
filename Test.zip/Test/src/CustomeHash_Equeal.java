
public class CustomeHash_Equeal {

	public int hashCode(String param){
		int result=1;
		int prime=31;
		result=prime * result + ((param==null) ? 0 :param.hashCode());
		return result;
	}
	public boolean equals(Object o)
	{
		if (o==null)
			return false;
		
		if(o==this)
			return true;
		if(getClass() !=o.getClass())
		return false;
		
		return true;
	}
}
