
public class ThirdLargestNo {
public static void thirdLargest(int arr[], 
        int arr_size)
	{
		
	 int first = arr[0]; 
	    for (int i = 1; 
	             i < arr_size ; i++) 
	        if (arr[i] > first) 
	            first = arr[i]; 
	  
	    // Find second  
	    // largest element 
	    int second = Integer.MIN_VALUE; 
	    for (int i = 0;  
	             i < arr_size ; i++) 
	        if (arr[i] > second &&  
	            arr[i] < first) 
	            second = arr[i]; 
	int third = Integer.MIN_VALUE; 
    for (int i = 0;  
             i < arr_size ; i++) 
        if (arr[i] > third &&  
            arr[i] < second) 
            third = arr[i]; 
  
    System.out.printf("The third Largest " +  
                  "element is %d\n", third);
}
    public static void main(String []args) 
    { 
        int arr[] = {12, 13, 1,  
                     10, 34, 16}; 
        int n = arr.length; 
      //  thirdLargest(arr, n); 
        int temp=0;
        for (int i = 0; i < arr.length; i++) {     
            for (int j = i+1; j < arr.length; j++) {     
               if(arr[i] > arr[j]) {    
                   temp = arr[i];    
                   arr[i] = arr[j];    
                   arr[j] = temp;    
               }     
            }     
        }    
          
        System.out.println();    
            
        //Displaying elements of array after sorting    
        System.out.println("Elements of array sorted in ascending order: ");    
        for (int i = 0; i < arr.length; i++) {     
            System.out.print(arr[i] + " ");    
        }
    } 
}
