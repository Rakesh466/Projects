import java.io.Serializable;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;



public class Test implements Comparable<Test> {
	public int id;
	public String name;
	public String deletePerson() {
		try{
			System.out.println("try");
			return "T1";
		}catch(Exception e)
		{
			System.out.println(e);
			return "C1";
		}finally{
			System.out.println("FF");

			//return "F1";
		}
		//return "M";
	}
	/*Integer id;
	Test(int id)
	{
		this.id=id;
	}*/
	/*public static void start(int i){
		System.out.println("c");
	}
	static int x=5;
	int z=5;
	final int y=6;*/
	static void start(int i){
		System.out.println("c");
	}
	public static void main(int[] args) {
	System.out.println("W");
	}
	public static void main(String[] args) {
		
		 
			 
		        String text = "a r b k c d se f g a d f s s f d s ft gh f ws w f v x s g h d h j j k f sd j e wed a d f";
		 
		        List<String> list = Arrays.asList(text.split(" "));
		 
		        Set<String> uniqueWords = new HashSet<String>(list);
		        for (String word : uniqueWords) {
		            System.out.println(word + ": " + Collections.frequency(list, word));
		        }
		 
		
		
		/*Test t=new Test();
		String f=t.deletePerson();
		System.out.println("F::"+f);*/
		/*int arr[]=new int[10];
		int i=5;
		arr[i++]=++i+i++;
		System.out.println(arr[5]+":"+arr[6]);*/
		/*Test1 t1=new Test();
		(Test)t1.start(4);*/
	/*	System.out.println("I");
	Test t1=new Test(3);
	Test t2=new Test(3);
	System.out.println(t1==t2);
	System.out.println(t1.equals(t2));
		byte b1=10;
		byte b2=20;*/
		//
		//byte b3=(byte)b1+b2;
	//	System.out.println(b1);
		//String x="XYZ";
		//System.out.println(x.equals(new Test1()));	
		/*Test t=new Test();
		t.x=7;
		t.z=9;
		t.y=8;*/
		//start(5);
		/*int i=2;
		int x[]={10,20,50,45,95,14};
		x[i]=x[i=i++];
		System.out.println(x[i]);*/

	}
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Test other = (Test) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (y != other.y)
			return false;
		if (z != other.z)
			return false;
		return true;
	}
*/
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public int compareTo(Test o) {
		// TODO Auto-generated method stub
		return 0;
	}
}
