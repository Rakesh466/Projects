package TestGroup.TestID;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Utility {
	//public static WebDriver driver= new ChromeDriver();;
	public static void selectFlightDate(String dt,String mnth,String yr,WebDriver driver) 
	{
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Users\\rakesh.mane\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com/");
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_originStation1_CTXTaction']")).click();
		driver.findElement(By.xpath("//div[@id='ctl00_mainContent_ddl_originStation1_CTNR']//div[@id='dropdownGroup1']"
		+ "//div//ul//li//a[contains(text(),' Ajmer (KQH)')]")).click();
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_destinationStation1_CTXTaction']")).click();
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_destinationStation1_CTXTaction']")).click();

		driver.findElement(
		By.xpath("//div[@id='ctl00_mainContent_ddl_destinationStation1_CTNR']//div[@id='dropdownGroup1']"
		+ "//div//ul//li//a[contains(text(),' Bagdogra (IXB)')]")).click();
		System.out.println("driver=" + driver); */

	// Month Selection
	List<WebElement> element1 = driver.findElements(By.xpath("//div[@id='ui-datepicker-div']//descendant::div[@class='ui-datepicker-title']//span[@class='ui-datepicker-month']"));
	for (int i = 0; i < element1.size(); i++)
	{
	System.out.println(element1.get(i).getText());
	if (element1.get(i).getText().equals(mnth))
		{
		}
	}

	// Year Selection

	List<WebElement> element2 = driver.findElements(By.xpath(
	"//div[@id='ui-datepicker-div']//descendant::div[@class='ui-datepicker-title']//span[@class='ui-datepicker-year']"));
	for (int j = 0; j < element2.size(); j++) 
	{
		System.out.println(element2.get(j).getText());
		if (element2.get(j).getText().equals(yr)) {
		}
	}
	// Date Selection

	List<WebElement> element3 = driver
	.findElements(By.xpath("//table[@class='ui-datepicker-calendar']//tr//td//a"));
	for (WebElement d : element3)
	{
		System.out.println("Dates are : " + d.getText());
		if (d.getText().equals(dt)) {
			d.click();
			return;
		}
	}
	}
	public static void main(String a[])
	{
		
		//selectFlightDate("10","Feb","2020");
		List list1=new ArrayList<>();
		list1.add("Rakesh");
		list1.add("Amit");
		System.out.println("List1:"+list1);
		List list2=new ArrayList<>();
		list2.add("Rajendra");
		list2.add("Vikas");
		System.out.println("List2:"+list2);
		System.out.println("ListAll"+list2.addAll(list1));
		System.out.println(list2);
		list2.remove("Amit");
		System.out.println(list2.retainAll(list2));
		System.out.println(list2);
	}
}
