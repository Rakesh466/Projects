package TestGroup.TestID;

import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {
	public static WebDriver driver;
	public static void main(String[] args) {
		/*String travelDate = "10-Febuary-2020";
		String spitter[] = travelDate.split("-");
		String date = spitter[0];
		String month = spitter[1];
		String year = spitter[2];
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\rakesh.mane\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("https://www.spicejet.com/");
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_originStation1_CTXTaction']")).click();
		driver.findElement(By.xpath("//div[@id='ctl00_mainContent_ddl_originStation1_CTNR']//div[@id='dropdownGroup1']"
		+ "//div//ul//li//a[contains(text(),' Ajmer (KQH)')]")).click();
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_destinationStation1_CTXTaction']")).click();
		driver.findElement(By.xpath("//span[@id='ctl00_mainContent_ddl_destinationStation1_CTXTaction']")).click();

		driver.findElement(
		By.xpath("//div[@id='ctl00_mainContent_ddl_destinationStation1_CTNR']//div[@id='dropdownGroup1']"
		+ "//div//ul//li//a[contains(text(),' Bagdogra (IXB)')]")).click();
		System.out.println("driver=" + driver);
		Utility.selectFlightDate(date,month,year,driver);*/
		try {
		Email email = new SimpleEmail();
		email.setHostName("smtp.gmail.com");
		email.setSmtpPort(465);
		//email.setAuthenticator(new DefaultAuthenticator("username", "password"));
		email.setSSLOnConnect(true);
		email.setFrom("rakeshm466@gmail.com");
		email.setSubject("TestMail");
		
		email.setMsg("This is a test mail ... :-)");
		email.addTo("pachangeamit@gmail.com");
		
		email.send();
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
