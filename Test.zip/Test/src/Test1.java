import java.io.Serializable;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import java.util.function.Consumer;

import sun.security.util.Length;


public class Test1 extends Test implements Serializable{
	/*static void start(int i){
		System.out.println("P");
	}
	Integer id;
	Test1(int id)
	{
		this.id=id;
	}*/
	public static void main(String t[])
	{
		String k="";
		String v="";
		 Map<String, String> countryMap = new HashMap<>();
	        countryMap.put("India", "Delhi");
	        countryMap.put("USA", "Washington, D.C.");
	        countryMap.put("Japan", "Tokyo");
	        countryMap.put("Canada", "Ottawa");
	 
	        // iterate through Map normal way
	        //countryMap.forEach((k,v)->System.out.println("Country: "+k+" : Capital: "+v));
	 
	        // iterate through Map using forEach method
	      //  ForEachMapEx.iterateMapUsingForEach(countryMap);
	        TreeSet<Test> treeSet=new TreeSet<Test>();
	        Test t1=new Test();
	        t1.setId(1);
	        t1.setName("Rakesh");
	        Test t2=new Test();
	        t2.setId(1);
	        t2.setName("Rakesh");
	        
	    // System.out.println(treeSet.add(t1));
	     //System.out.println(treeSet.add(t2));
	        String s1="Rakesh";
	        String s2="MAHAMA";
	        String s3=new String("MAHAMA");//creates two objects and one reference variable  
	       // System.out.println(recursion(12345));
	        System.out.println(reverseRecursive(12345,0));
 //System.out.println(s1==s2);
	/*        for (int i=s1.length()-1;i>=0;i--)
	        {
	        	s2=s2+s1.charAt(i);
	        }
	       // System.out.println(s2);
	        System.out.println(recursion(s1));
	        //System.out.println("S1:"+s1.equals(s3));
	        
	        //String jo=String.join("-", s1,s3);
	       // System.out.println(jo);
	       //System.out.println(s1.concat("abcs"));
	        String s4=s3.intern();
	       // System.out.println(s1==s4);
	        String s=20+30+"r"+30+1;
	        System.out.println(s);*/
	}
public static String recursion(String rev)
{
	if (rev.isEmpty())
	return rev;
	System.out.println("rev:"+rev);
	System.out.println("rev.substring(1):"+rev.substring(1));
	System.out.println("rev.charAt(0):"+rev.charAt(0));

	return recursion(rev.substring(1))+rev.charAt(0);
}

public static Integer recursion(Integer num)
{
	if(num < 1) {
        return 0;
    }

    int temp = num % 10;
    num = (num - temp)/10;
    System.out.println(temp);

	return recursion(num);
}
public static int reverseRecursive(int n, int reverse) {// n - the number to reverse
     System.out.println(n);

    if (n != 0){
        reverse = reverse * 10;
        reverse = reverse + n %10;
        n = n/10;
    } else {
          return reverse;
    }
return reverseRecursive(n,reverse);
}
}
