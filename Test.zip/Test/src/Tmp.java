
public class Tmp {
	 public static int staticVar;
	    public int nonStaticVar;
	    
	    public static int getStaticVar(){
	    	
	        return staticVar;
	    }
	    
	    static class StaticInnerClas
	    {  
	        public static void accessOuterClass()
	        {
	            System.out.println(Tmp.staticVar);       //static variable of outer class
	            System.out.println(Tmp.getStaticVar());  //static method of outer class
	        }
	    }
}
