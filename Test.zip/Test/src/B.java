import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;


public class B extends A
{
	public String print()  
	{
		System.out.println("i am in B");
		return "S";
	}
	public static void main(String[] args) {
		
		A a=new B();
		try {
			a.print();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* ArrayList<String> list = new ArrayList<>(2);
         
	        list.add("A");
	        list.add("B");
	        list.add("C");
	        list.add("D");
	       // list.ensureCapacity(0);

	        System.out.println( list.size()); 
	        System.out.println( list.indexOf("A") > 0);    
	        
	        int lastIndex = list.lastIndexOf("alex");
	         
	        System.out.println(lastIndex);
	 
	        lastIndex = list.lastIndexOf("D");
	         
	        System.out.println(lastIndex);
	        //list.remove(10);
	       // System.out.println( list.removeAll(list));
	       // System.out.println(list);
	       // System.out.println(list.retainAll(Collections.singleton("A")));
	       // System.out.println(list.replaceAll(operator));
	        //list.subList(1, 3).clear();
	       Object o[]= list.toArray();
	       System.out.println(Arrays.toString(o));
	        System.out.println(list);

	        Collections.swap(list, 0, 3);

	        System.out.println(list);*/
	}

}
