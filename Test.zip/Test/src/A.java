import java.io.FileNotFoundException;
import java.io.IOException;


public class A 
{
	public String print() throws ArrayIndexOutOfBoundsException
	{
		System.out.println("i am in A");
		return "";
	}
}
