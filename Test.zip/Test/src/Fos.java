import java.util.HashMap;
import java.util.Map;


public class Fos {

	public static void main(String[] args) {
		String cur="ABCDE";
		String arr[]={"ABCEDA","ABCDEZS","BCDA"};
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("---i------");
			//for(int j=0;j< arr[i].length();j++)
			//{
				String temp1=arr[i];
				System.out.println("--temp1------"+temp1);
				Map map=new HashMap<String,Integer>();
				int count=0;
				for(int k=0; k<temp1.length();k++)
				{
					System.out.println("temp1.charAt(k):"+temp1.charAt(k));
					if(map.containsKey(temp1.charAt(k)))
					{
						//map.put(cur.charAt(h),count++);
						int cnt=(int) map.get(temp1.charAt(k));
						System.out.println("Cnt:"+cnt);
						/*if(cnt>=1)
						{*/
						System.out.println("Duplicate :"+temp1.charAt(k));
						//break;
						//}
					}
					for(int h=0; h<cur.length();h++)
					{
						//System.out.println("map.containsKey(cur.charAt(h)):"+map);
						
						if(temp1.charAt(k)==cur.charAt(h))
						{
							char ch=temp1.charAt(k);
							map.put(ch,count++);
							System.out.println("arr[j]: "+temp1.charAt(k)+" cur.charAt(k):"+cur.charAt(h));
						
						}else{
							int index=cur.indexOf(temp1.charAt(k));
							System.out.println("Index::"+index);
							//System.out.println("not match:"+temp1.charAt(k)+" "+cur.charAt(h));
						}
						
					}
				}
			//}
		}
		
	
	
	}
/*	String genePwd="";
	try {
		MessageDigest m= MessageDigest.getInstance("SHA-1");
		m.update(cur.getBytes());
		byte s[]=m.digest();
		 StringBuilder sb = new StringBuilder();
            for(int i=0; i< s.length ;i++)
            {
                sb.append(Integer.toString((s[i] & 0xff) + 0x100, 16).substring(1));
            }
            //Get complete hashed password in hex format
            genePwd = sb.toString();
            System.out.println(genePwd);//2ecdde3959051d913f61b14579ea136d
	} catch (NoSuchAlgorithmException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
}
