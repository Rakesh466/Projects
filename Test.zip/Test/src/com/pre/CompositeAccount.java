package com.pre;

public class CompositeAccount extends Component{
	private float totalBalance;
    private AccountStatement compositeStmt, individualStmt;
	@Override
	public float getBalance() {
		totalBalance=0;
		for(Component c:list)
		{
			System.out.println("balance:"+c.getBalance());
			totalBalance=totalBalance+c.getBalance();
		}
		return totalBalance;
	}

	@Override
	public AccountStatement getStatement() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
