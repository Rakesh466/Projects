import java.text.DecimalFormat;


public class Chg {

	public static void main(String[] args) {
		 double fCGSTPercent = 9;
		    double fSGSTPercent = 9;
		    double fIGSTPercent = 18;
		    double fTotalTax = 0.0D;
		    double fCurrentTax = 0.0D;
		    double fCGSTCurrentTax = 0.0D;
		    double fSGSTCurrentTax = 0.0D;
		    double fIGSTCurrentTax = 0.0D;
		    double fChargeAmount = 1050; 
		    DecimalFormat df2 = new DecimalFormat(".##");
		Double dMultiplier = Double.valueOf(100.0D + (fCGSTPercent + fSGSTPercent));
        
        fCGSTCurrentTax = fChargeAmount * fCGSTPercent / dMultiplier.doubleValue();
        fCGSTCurrentTax = Double.valueOf(df2.format(fCGSTCurrentTax)).doubleValue();
        System.out.println("Inclusive fCGSTCurrentTax:" + fCGSTCurrentTax);
        
        fSGSTCurrentTax = fChargeAmount * fSGSTPercent / dMultiplier.doubleValue();
        fSGSTCurrentTax = Double.valueOf(df2.format(fSGSTCurrentTax)).doubleValue();
        System.out.println("Inclusive fSGSTCurrentTax:" + fSGSTCurrentTax);
        
        fTotalTax += fCGSTCurrentTax + fSGSTCurrentTax;
        //System.out.println(fTotalTax);
        double fAmount=1050;
        double fPercent=9;
        double fPercentVal=0d;
        fPercentVal = fAmount * fPercent / 100.0D;
        System.out.println(fPercentVal);
	}

}
