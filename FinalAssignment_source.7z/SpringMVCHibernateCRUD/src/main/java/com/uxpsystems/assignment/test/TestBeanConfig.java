package com.uxpsystems.assignment.test;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan(basePackages = "com.upxsystem.assignment.test")
public class TestBeanConfig {

}
