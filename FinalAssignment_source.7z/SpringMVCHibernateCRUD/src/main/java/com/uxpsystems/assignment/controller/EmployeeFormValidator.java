package com.uxpsystems.assignment.controller;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import com.uxpsystems.assignment.model.Employee;
@Component
public class EmployeeFormValidator implements Validator {

	//which objects can be validated by this validator
	@Override
	public boolean supports(Class<?> paramClass) {
		return Employee.class.equals(paramClass);
	}

	@Override
	public void validate(Object obj, Errors errors) {
		//ValidationUtils.rejectIfEmptyOrWhitespace(errors, "id", "id.required");
		
		/*
		 * Employee emp = (Employee) obj; if(emp.getId() <=0){ errors.rejectValue("id",
		 * "negativeValue", new Object[]{"'id'"}, "id can't be negative"); }
		 */
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required" ,"Name id required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "email.required","Email id required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "address.required","Address id required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "telephone", "telephone.required","Telephone id required");
	}
}
