package com.org.server.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;



@XmlRootElement
public class Person {
	
	private String name;
	
	private int age;
	
	private int id;
	//@XmlElement(name = "name")
	public String getName() {
		return name;
	}
	//@XmlElement
	public void setName(String name) {
		this.name = name;
	}
//	@XmlElement(name="age")
	public int getAge() {
		return age;
	}
	//@XmlElement
	public void setAge(int age) {
		this.age = age;
	}
	//@XmlElement(name="id")
	public int getId() {
		return id;
	}
//	@XmlElement
	public void setId(int id) {
		this.id = id;
	}
}
