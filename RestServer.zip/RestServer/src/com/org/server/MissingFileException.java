package com.org.server;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;

public class MissingFileException extends Exception implements ExceptionMapper<MissingFileException> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/*public MissingFileException()
	{
		super("No File found with given name !!");
	}
	public MissingFileException(String msg)
	{
		super(msg);
	}*/
	
	@Override
	public Response toResponse(MissingFileException excep) {
		System.out.println("Sending.........");
		return Response.status(404).entity("Custome exception").type("text/json").build();
		
	}
	

}
