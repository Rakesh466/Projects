package com.org.server;


import javax.ws.rs.core.Response;

import com.org.server.model.Person;

public interface PersonService {
public Response addPerson(Person p);
	
	public Response deletePerson(int id);
	
	public Response getPerson(int id);
	
	public Person[] getAllPersons();
}
