package com.org.server;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.org.server.model.Person;

@Path("/person")
//@Consumes(MediaType.APPLICATION_XML)
//@Produces(MediaType.APPLICATION_XML)
public class PersonServiceImpl implements PersonService{
	private static Map<Integer,Person> persons = new HashMap<Integer,Person>();

	/*@Override
	@POST
	@Path("/add")
	public Response addPerson(Person p) {
		System.out.println("Inside ....add....");
		Response response = new Response();
		if(persons.get(p.getId()) != null){
			response.setStatus(false);
			response.setMessage("Person Already Exists");
			return response;
		}
		persons.put(p.getId(), p);
		response.setStatus(true);
		response.setMessage("Person created successfully");
		return response;
		
	}*/

	@Override
	public Response deletePerson(int id) {
		try{
			System.out.println("try");
			return null;
		}catch(Exception e)
		{
			System.out.println(e);
			return null;
		}finally{
			return null;
		}
		
	}
	
	@POST
	@Path("/getP")
	@Override
	@Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
	public Response getPerson(int id) {
		System.out.println("Get person");
		Person p=new Person();
		p.setId(1);
		p.setAge(25);
		p.setName("Rakesh");
		return  Response.status(200).entity(p).build();
	}
	/*@GET
	@Path("/apples")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public List getApples() {
	//List retVal = new ArrayList(apples.values());
	//Collections.sort(retVal, comparator);
	return retVal;
	}*/
	@Override
	public Person[] getAllPersons() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@GET
    @Path("/query/{empid}")
    public Response getEmployeeQuery(@PathParam("empid") String empid){
         
        /** read complete employee id list from request query parameter**/
        //List<String> empIdList = uriInfo.getQueryParameters().get("id");
      //  System.out.println("Received List: "+empIdList);
        /** read first employee id from request query parameter **/
       // String firstEmpId = uriInfo.getQueryParameters().getFirst("id");
       // System.out.println("First emp record from the request: "+firstEmpId);
         System.out.println(empid);
        return Response.status(200).entity("processed request::"+empid).build();
    }
	@GET
    @Path("/query")
	@Produces(MediaType.APPLICATION_JSON)
	//@Consumes({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
    public Response getEmployeeQuery
    (@QueryParam("branch") String branch,@QueryParam("department") String dept)
    		throws MissingFileException
	{
         System.out.println("-----------");
        /** read complete employee id list from request query parameter**/
        //List<String> empIdList = uriInfo.getQueryParameters().get("id");
      //  System.out.println("Received List: "+empIdList);
        /** read first employee id from request query parameter **/
       // String firstEmpId = uriInfo.getQueryParameters().getFirst("id");
       // System.out.println("First emp record from the request: "+firstEmpId);
		if(null==branch)
		{
			System.out.println("--Exce--------");
			throw new MissingFileException();
		}
         System.out.println(dept);
        return Response.status(200).entity("Branch::"+branch+" Department::"+dept).build();
    }
	@Override
	public Response addPerson(Person p) {
		// TODO Auto-generated method stub
		return null;
	}

	/*@POST
    @Path("/query")
    public Response getEmployeeQuery(@Context UriInfo uriInfo){
		  List<String> empIdList = uriInfo.getQueryParameters().get("id");
	        System.out.println("Received List: "+empIdList);
		String firstEmpId = uriInfo.getQueryParameters().getFirst("id");
		System.out.println(firstEmpId);
        return Response.status(200).entity("Branch::").build();
    }*/
	 	@GET
	    @Path("http-header")
	    public Response queryHeaderInfo(@HeaderParam("Cache-Control") String ccControl,
	                                        @HeaderParam("User-Agent") String uaStr){
	         
	        String resp = "Received http headers are Cache-Control: "+ccControl+
	                        "<br>User-Agent: "+uaStr;
	        System.out.println(resp);
	        return Response.status(200).entity(resp).build();
	    } 
}
